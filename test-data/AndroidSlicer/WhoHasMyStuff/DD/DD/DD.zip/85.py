#start monkey test seedNo 0
import os;
from subprocess import Popen
from subprocess import PIPE
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
from com.android.monkeyrunner.MonkeyDevice import takeSnapshot
from com.android.monkeyrunner.easy import EasyMonkeyDevice
from com.android.monkeyrunner.easy import By
from com.android.chimpchat.hierarchyviewer import HierarchyViewer
from com.android.monkeyrunner import MonkeyView
import random
import sys
import subprocess
from sys import exit
from random import randint
device = MonkeyRunner.waitForConnection()
package = 'de.freewarepoint.whohasmystuff'
activity ='de.freewarepoint.whohasmystuff.ListLentObjects'
runComponent = package+'/'+activity
device.startActivity(component=runComponent)
MonkeyRunner.sleep(0.1)
MonkeyRunner.sleep(0.1)
device.touch(151,231, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(641,1377, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(218,1644, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(202,1633, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(292,1095, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1029,733, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(157,1143, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(157,1643, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(830,1325, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(154,588, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(336,388, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(145,1224, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1051,618, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(71,138, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(419,370, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(127,470, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(537,335, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(852,1710, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(902,1234, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(144,1165, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(985,220, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(693,476, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(901,1057, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(98,1585, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(430,1584, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(11,1172, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(989,1088, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(26,864, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(302,966, 'DOWN_AND_UP')
