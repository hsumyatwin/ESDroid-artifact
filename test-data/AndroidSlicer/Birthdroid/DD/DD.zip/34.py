#start monkey test seedNo 0
import os;
from subprocess import Popen
from subprocess import PIPE
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
from com.android.monkeyrunner.MonkeyDevice import takeSnapshot
from com.android.monkeyrunner.easy import EasyMonkeyDevice
from com.android.monkeyrunner.easy import By
from com.android.chimpchat.hierarchyviewer import HierarchyViewer
from com.android.monkeyrunner import MonkeyView
import random
import sys
import subprocess
from sys import exit
from random import randint
device = MonkeyRunner.waitForConnection()
package = 'com.rigid.birthdroid'
activity ='com.rigid.birthdroid.BirthdroidActivity'
runComponent = package+'/'+activity
device.startActivity(component=runComponent)
MonkeyRunner.sleep(0.3)
MonkeyRunner.sleep(0.3)
device.touch(622,229, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(599,934, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(400,886, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(935,1032, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(88,1725, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(293,489, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(186,154, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(971,1453, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(322,1141, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(311,1653, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(611,1668, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(1012,1438, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(634,462, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(587,649, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(684,598, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(983,1534, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(981,1536, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(985,1530, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(757,772, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(232,1851, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(230,1848, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.3)
device.touch(229,1846, 'DOWN_AND_UP')
