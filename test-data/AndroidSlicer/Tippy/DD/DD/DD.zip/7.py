#start monkey test seedNo 0
import os;
from subprocess import Popen
from subprocess import PIPE
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
from com.android.monkeyrunner.MonkeyDevice import takeSnapshot
from com.android.monkeyrunner.easy import EasyMonkeyDevice
from com.android.monkeyrunner.easy import By
from com.android.chimpchat.hierarchyviewer import HierarchyViewer
from com.android.monkeyrunner import MonkeyView
import random
import sys
import subprocess
from sys import exit
from random import randint
device = MonkeyRunner.waitForConnection()
package = 'net.mandaria.tippytipper'
activity ='net.mandaria.tippytipper.activities.TippyTipper'
runComponent = package+'/'+activity
device.startActivity(component=runComponent)
MonkeyRunner.sleep(0.1)
MonkeyRunner.sleep(0.1)
device.touch(366,1557, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1050,1568, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(662,379, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(235,1549, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(10,1268, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(833,1303, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(228,1425, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1021,94, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(426,1547, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(849,1789, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(954,364, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1039,1323, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(732,1462, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(477,869, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(921,938, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1072,1747, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(381,151, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(77,120, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(522,1752, 'DOWN_AND_UP')
