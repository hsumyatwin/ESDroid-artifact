#start monkey test seedNo 0
import os;
from subprocess import Popen
from subprocess import PIPE
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
from com.android.monkeyrunner.MonkeyDevice import takeSnapshot
from com.android.monkeyrunner.easy import EasyMonkeyDevice
from com.android.monkeyrunner.easy import By
from com.android.chimpchat.hierarchyviewer import HierarchyViewer
from com.android.monkeyrunner import MonkeyView
import random
import sys
import subprocess
from sys import exit
from random import randint
device = MonkeyRunner.waitForConnection()
package = 'net.mandaria.tippytipper'
activity ='net.mandaria.tippytipper.activities.TippyTipper'
runComponent = package+'/'+activity
device.startActivity(component=runComponent)
MonkeyRunner.sleep(0.1)
MonkeyRunner.sleep(0.1)
device.touch(522,1752, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(965,585, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(463,1260, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(441,681, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(726,1351, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(966,1073, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(552,610, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(583,1754, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(663,117, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(744,1161, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(884,1352, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(682,615, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(811,399, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(132,1304, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1008,608, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(572,379, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(123,1253, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(409,1095, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(1016,994, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(231,647, 'DOWN_AND_UP')
