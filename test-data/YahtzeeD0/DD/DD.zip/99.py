#start monkey test seedNo 0
import os;
from subprocess import Popen
from subprocess import PIPE
from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
from com.android.monkeyrunner.MonkeyDevice import takeSnapshot
from com.android.monkeyrunner.easy import EasyMonkeyDevice
from com.android.monkeyrunner.easy import By
from com.android.chimpchat.hierarchyviewer import HierarchyViewer
from com.android.monkeyrunner import MonkeyView
import random
import sys
import subprocess
from sys import exit
from random import randint
device = MonkeyRunner.waitForConnection()
package = 'com.tum.yahtzee'
activity ='com.tum.yahtzee.YahtzeeActivity'
runComponent = package+'/'+activity
device.startActivity(component=runComponent)
MonkeyRunner.sleep(0.1)
MonkeyRunner.sleep(0.1)
device.touch(1016,994, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(231,647, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(270,1343, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(98,527, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(93,1614, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(577,218, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(378,1776, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(622,1115, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(983,103, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(296,1227, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(652,1329, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(328,1152, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(38,896, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(100,1300, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(469,1488, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(653,1233, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(486,666, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(291,1359, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(222,328, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(994,1260, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(990,131, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(210,1067, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(747,1456, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(780,661, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(68,674, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(563,1725, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(749,280, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(546,1630, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(180,674, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(751,126, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(317,1066, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(182,713, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(117,1689, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(946,1544, 'DOWN_AND_UP')
MonkeyRunner.sleep(0.1)
device.touch(426,724, 'DOWN_AND_UP')
